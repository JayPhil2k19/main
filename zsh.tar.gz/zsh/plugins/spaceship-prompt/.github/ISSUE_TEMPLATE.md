<!--
Thanks for filing an issue 😄

BEFORE SUBMITTING NEW ISSUE, PLEASE, READ THE TROUBLESHOOTING PAGE!

https://spaceship-prompt.sh/troubleshooting

Check the other issue templates if you are trying to submit a bug report, feature request, or question.
Search open/closed issues before submitting since someone might have asked the same thing before!
-->
